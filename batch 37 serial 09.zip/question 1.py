import numpy as np

# Create a 4x4 unit matrix (all ones)
unit_matrix = np.ones((4, 4))

# Create a 4x4 identity matrix
identity_matrix = np.eye(4)

# Summation of two matrices
result_matrix = unit_matrix + identity_matrix

# Transpose of the resulting matrix
transpose_matrix = result_matrix.T

# Print the matrices
print("Unit Matrix:")
print(unit_matrix)
print("\nIdentity Matrix:")
print(identity_matrix)
print("\nSummation of Unit and Identity Matrix:")
print(result_matrix)
print("\nTranspose of the Resulted Matrix:")
print(transpose_matrix)
