import pandas as pd
 # a. Load the dataset
 data = pd.read_csv("Dataset_Batch37.csv")
 print(data)

#(b and c) Develope a machine learning model based on support vector machine-

 #Slicing the dataset
 x=data.iloc[:,2:3].values
y=data.iloc[:,4].values
 # print(x)

 # splitting the dataset
 from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.3,random_state=0)
 # print(x_train)
 # print(x_test)

from sklearn.preprocessing import MinMaxScaler
 scale1=MinMaxScaler()
 x_train=scale1.fit_transform(x_train)
 # print(x_train)
 # print(x_test)

from sklearn.svm import SVC
 cli=SVC(kernel="linear",random_state=0)
cli.fit(x_train,y_train)
 y_predict=cli.predict(x_test)

 from sklearn.metrics import confusion_matrix,accuracy_score
cm=confusion_matrix(y_test,y_predict) print(cm) acc=accuracy_score(y_test,y_predict)
print(acc)

